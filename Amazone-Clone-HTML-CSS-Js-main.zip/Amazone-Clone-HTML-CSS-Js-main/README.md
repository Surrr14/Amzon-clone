# Amazone-Clone-HTML-CSS-Js
Cloning Amazone Website using html css java script
